@extends('layouts.app')
@section('title', '| Tooted')
@section('content')

@endsection

