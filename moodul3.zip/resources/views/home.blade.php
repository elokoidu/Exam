@extends('layouts.app')
@section('title', '| Avaleht')
@section('content')
    @include('layouts.hero')
@endsection
@section('content')
    @include('partials._item')
@endsection
