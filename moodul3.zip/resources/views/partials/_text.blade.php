<div class="uk-align-center uk-margin-large-left uk-margin-large-right">
    <h1><strong>{{ $products->nimi }}</strong></h1>
    <h2><strong>Hind</strong> {{ $products->hind }}€</h2>
    <p>{{ $products->näitajad }}</p>
</div>
