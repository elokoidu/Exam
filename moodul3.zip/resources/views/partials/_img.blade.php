<img src="{{ $products->tootefoto }}" data-srcset="" sizes="" width="500" height="" alt="" uk-img>
