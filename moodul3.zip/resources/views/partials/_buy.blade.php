<div class="uk-align-center uk-margin-large-left uk-margin-large-right">
    <p>{{ $products->kirjeldus }}</p>
    <button class="uk-button-primary uk-button-large">Lisa ostukorvi</button>
</div>
