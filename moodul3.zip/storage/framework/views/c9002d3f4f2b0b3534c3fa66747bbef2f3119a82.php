<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="uk-grid-small">
        <div
            class="uk-card uk-card-small uk-card-default uk-align-center uk-margin-large-top uk-width-medium uk-card-hover uk-text-center">
            <div class="uk-card-media-top uk-card-header">
                <a href="/detail"><img src="<?php echo e($product->tootefoto); ?>" alt="Image"></a>
                <button class="uk-button uk-button-primary uk-card-badge"><a href="#" uk-icon="icon: cart"></a></button>
            </div>
            <div class="uk-card uk-card-body">
                <a href="<?php echo e(url('products/'.$product->slug)); ?>"><h2 class="uk-card-title"><?php echo e($product->nimi); ?>

                        <br><?php echo e($product->hind); ?></h2></a>
                <p><?php echo e(substr($product->kirjeldus, 0, 40)); ?> <?php echo e(strlen($product->kirjeldus) > 40 ? '...' : ''); ?></p>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\eloko\Desktop\TeraFlop\teraflop\resources\views/partials/_item.blade.php ENDPATH**/ ?>