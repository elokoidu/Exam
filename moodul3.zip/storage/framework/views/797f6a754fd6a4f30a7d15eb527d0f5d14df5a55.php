<div>
<div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slideshow="animation: push; min-height: 100; max-height: 400; autoplay: true; autoplay-interval: 5000">
    <ul class="uk-slideshow-items">
        <li>
            <img src="img/banner1.png" alt="" uk-cover>
        </li>
        <li>
            <img src="img/banner2.png" alt="" uk-cover>
        </li>
        <li>
            <img src="img/banner3.jpg" alt="" uk-cover>
        </li>
    </ul>
    <div class="uk-overlay uk-position-cover uk-overlay-primary uk-hidden@m">
        <h4 class="uk-position-center" id="hero">Kõik mida vajad, alati kui vajad</h4>
    </div>
    <div class="uk-overlay uk-position-cover uk-overlay-primary uk-visible@m">
        <h1 class="uk-position-center" id="hero">Kõik mida vajad, alati kui vajad</h1>
    </div>
    <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slideshow-item="previous"></a>
    <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slideshow-item="next"></a>
</div>
</div>
<?php /**PATH C:\Users\eloko\Desktop\vol2\mysite\resources\views/hero.blade.php ENDPATH**/ ?>