<?php $__env->startSection('title', '| Muuda toodet'); ?>

<?php $__env->startSection('content'); ?>
<div class="uk-margin-large-left uk-margin-large-top">
    <?php echo Form::model($product, ['route' => ['products.update', $product->id], 'method' => 'PUT']); ?>

        <h1><?php echo e($product->nimi); ?> <?php echo e($product->hind); ?></h1>
        <table class="uk-table uk-table-medium uk-table-divider uk-table-justify">
            <tbody>
            <tr><td><strong>Tootekood: </strong><?php echo e(Form::number('tootekood', null, ['class' => 'form-control'])); ?></td></tr>
            <tr><td><strong>Tootefoto: </strong><?php echo e(Form::text('tootefoto', null, ['class' => 'form-control'])); ?></td></tr>
            <tr><td><strong>Näitajad: </strong><?php echo e(Form::textarea('näitajad', null, ['class' => 'form-control'])); ?></td></tr>
            <tr><td><strong>Tootja: </strong><?php echo e(Form::text('tootja', null, ['class' => 'form-control'])); ?></td></tr>
            <tr><td><strong>Kategooria: </strong><?php echo e(Form::select('kategooria', ['Monitor', 'Lisatarvikud', 'Emaplaat', 'Kõvaketas', 'Graafikakaart'], ['class' => 'form-control'])); ?></td></tr>
            <tr><td><strong>Kirjeldus: </strong><?php echo e(Form::textarea('kirjeldus', null, ['class' => 'form-control'])); ?></td></tr>
            </tbody>
        </table>
</div>
<div class="uk-margin-large-left uk-margin-medium-bottom">
        <?php echo Html::linkRoute('products.show', 'Tühista', array($product->id), array('class' => 'uk-button uk-button-danger')); ?>

        <?php echo e(Form::submit('Salvesta muudatused', ['class' => 'uk-button uk-button-primary'])); ?>

    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eloko\Desktop\TeraFlop\teraflop\resources\views/products/edit.blade.php ENDPATH**/ ?>