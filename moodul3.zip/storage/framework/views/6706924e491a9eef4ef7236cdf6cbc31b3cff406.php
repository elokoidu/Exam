<li><a target="_blank" href="https://vuejs.org/">Vue.js Website</a></li>
<li><a target="_blank" href="https://vuejs.org/v2/guide/">Vue.js Guide</a></li>
<li><a target="_blank" href="https://news.vuejs.org/">Vue.js News</a></li>
<li><a target="_blank" href="https://medium.com/the-vue-point">Vue.js Blog</a></li>
<li><a target="_blank" href="https://github.com/vuejs/vue">Vue.js on GitHub</a></li>
<li><a target="_blank" href="https://github.com/vuejs/awesome-vue">Awesome Vue</a></li>
<?php /**PATH C:\Users\eloko\Desktop\vol2\mysite\resources\views/vuejs.blade.php ENDPATH**/ ?>