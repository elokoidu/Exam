<!DOCTYPE html>
<html>
<head>
    <title>Title</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/uikit.min.css" />
    <script src="js/uikit.min.js"></script>
    <script src="js/uikit-icons.min.js"></script>
</head>
<body>

<h2>Hey, welcome!</h2>
</body>
</html>
<?php /**PATH C:\Users\eloko\Desktop\vol2\mysite\resources\views/product.blade.php ENDPATH**/ ?>