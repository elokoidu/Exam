<?php $__env->startSection('title', '| Uus toode'); ?>
<?php $__env->startSection('stylesheets'); ?>
    <?php echo Html::style('css/parsley.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="uk-grid uk-width-1-5@m uk-margin-xlarge-left uk-margin-large-top">
        <h2 class="">Lisa uus toode</h2>
        <hr>
        <div class="uk-margin-medium-top">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        <?php echo e(Form::open(array('route' => 'products.store', 'files' => 'true','method' => 'post', 'class' => 'uk-form-controls-text uk-form-width-large'))); ?>

            <?php echo e(Form::label('nimi', 'Nimi')); ?>

            <?php echo e(Form::text('nimi', null, array('class' => 'uk-margin-small-top uk-input'))); ?>

        <hr>
            <?php echo e(Form::label('hind', 'Hind')); ?>

            <?php echo e(Form::number('hind', null, array('class' => 'uk-margin-small-top uk-input', 'step'=>'0.1', 'min' => '0'))); ?>

        <hr>
            <?php echo e(Form::label('tootekood', 'Tootekood')); ?>

            <?php echo e(Form::number('tootekood', null, array('class' => 'uk-margin-small-top uk-input'))); ?>

        <hr>
            <?php echo e(Form::label('tootefoto', 'Tootefoto')); ?>

            <?php echo e(Form::url('tootefoto', null, array('class' => 'uk-margin-small-top uk-input'))); ?>

        <hr>
            <?php echo e(Form::label('näitajad', 'Näitajad')); ?>

            <?php echo e(Form::text('näitajad', null, array('class' => 'uk-margin-small-top uk-input'))); ?>

        <hr>
            <?php echo e(Form::label('tootja', 'Tootja')); ?>

            <?php echo e(Form::text('tootja', null, array('class' => 'uk-margin-small-top uk-input'))); ?>

        <hr>
            <?php echo e(Form::label('kategooria', 'Kategooria')); ?>

            <?php echo e(Form::select('kategooria', ['Monitor', 'Lisatarvikud', 'Emaplaat', 'Kõvaketas', 'Graafikakaart'], array('class' => 'uk-margin-small-top uk-input'))); ?>

        <hr>
            <?php echo e(Form::label('kirjeldus', 'kirjeldus')); ?>

            <?php echo e(Form::text('kirjeldus', null, array('class' => 'uk-margin-small-top uk-input'))); ?>

        <hr>
            <?php echo e(Form::label('slug', 'Slug')); ?>

            <?php echo e(Form::text('slug', null, array('class' => 'uk-margin-small-top uk-input'))); ?>

        <hr>
            <?php echo e(Form::submit('Lisa uus toode', array('class' => 'uk-button uk-button-default uk-margin-medium-bottom'))); ?>

        <?php echo e(Form::close()); ?>

    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('js/parsley.min.js'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eloko\Desktop\TeraFlop\teraflop\resources\views/products/create.blade.php ENDPATH**/ ?>