<li><a target="_blank" href="https://getuikit.com/">UIkit Website</a></li>
<li><a target="_blank" href="https://getuikit.com/docs">UIkit Docs</a></li>
<li><a target="_blank" href="https://getuikit.com/changelog">UIkit Changelog</a></li>
<li><a target="_blank" href="https://twitter.com/getuikit">UIkit on Twitter</a></li>
<li><a target="_blank" href="https://github.com/uikit/uikit">UIkit on GitHub</a></li>
<li><a target="_blank" href="https://github.com/uikit/awesome-uikit">Awesome UIkit</a></li>
<li><a target="_blank" href="https://zzseba78.github.io/Kick-Off/">KickOff - Starter Templates</a></li>
<?php /**PATH C:\Users\eloko\Desktop\vol2\mysite\resources\views/uikit.blade.php ENDPATH**/ ?>