
<?php $__env->startSection('title', '| Kõik tooted'); ?>

<?php $__env->startSection('content'); ?>

<div class="uk-margin-large-top uk-margin-large-left">
    <h1>Kõik tooted</h1>
    <a href="<?php echo e(route('products.create')); ?>"><button class="uk-button uk-button-primary">Lisa uus toode</button></a>
</div>
    <div class="uk-visible@l uk-margin-medium-top">
        <table class="uk-table uk-margin-large-left uk-width-1-1 uk-margin-small-right">
            <thead>
                <th>#</th>
                <th>Nimi</th>
                <th>Hind</th>
                <th>Tootekood</th>
                <th>Tootefoto</th>
                <th>Näitajad</th>
                <th>Tootja</th>
                <th>Kategooria</th>
                <th>Kirjeldus</th>
                <th></th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->nimi); ?></td>
                    <td><?php echo e($product->hind); ?></td>
                    <td><?php echo e($product->tootekood); ?></td>
                    <td><?php echo e(substr($product->tootefoto, 0, 20)); ?> <?php echo e(strlen($product->tootefoto) > 20 ? '...' : ''); ?></td>
                    <td><?php echo e(substr($product->näitajad, 0, 40)); ?> <?php echo e(strlen($product->näitajad) > 40 ? '...' : ''); ?></td>
                    <td><?php echo e($product->tootja); ?></td>
                    <td><?php echo e($product->kategooria); ?></td>
                    <td><?php echo e(substr($product->kirjeldus, 0, 25 )); ?><?php echo e(strlen($product->kirjeldus) > 25 ? '...' : ''); ?></td>
                    <td><a href="<?php echo e(route('products.show', $product->id)); ?>" class="uk-button uk-button-primary uk-button-small">Vaata</a>
                        <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="uk-button uk-button-primary uk-button-small">Muuda</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="uk-pagination uk-flex uk-flex-center uk-text-large uk-margin-medium-top">
            <?php echo $products->render();; ?>

        </div>
    </div>
<div class="uk-hidden@l uk-visible@m uk-width-1-1 uk-margin-medium-left">
    <table class="uk-table">
        <thead>
        <th>#</th>
        <th>Nimi</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e(substr($product->nimi, 0, 15)); ?></td>
                <td><?php echo e(substr($product->näitajad, 0, 30)); ?> <?php echo e(strlen($product->näitajad) > 30 ? '...' : ''); ?></td>
                <td><a href="<?php echo e(route('products.show', $product->id)); ?>" class="uk-button uk-button-primary uk-button-small">Vaata</a>
                    <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="uk-button uk-button-primary uk-button-small">Muuda</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="uk-pagination uk-flex uk-flex-center uk-text-large uk-margin-medium-top">
        <?php echo $products->render();; ?>

    </div>
</div>
<div class="uk-hidden@m uk-width-1-1 uk-margin-medium-left">
    <table class="uk-table">
        <thead>
        <th>#</th>
        <th>Nimi</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e(substr($product->nimi, 0, 25)); ?></td>
                <td><a href="<?php echo e(route('products.show', $product->id)); ?>" class="uk-button uk-button-primary uk-button-small">Vaata</a>
                    <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="uk-button uk-button-primary uk-button-small">Muuda</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="uk-pagination uk-flex uk-flex-center uk-text-small uk-margin-medium-top">
        <?php echo $products->render();; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eloko\Desktop\TeraFlop\teraflop\resources\views/products/index.blade.php ENDPATH**/ ?>