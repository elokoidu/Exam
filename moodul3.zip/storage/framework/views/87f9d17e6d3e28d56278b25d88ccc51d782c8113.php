<li><a target="_blank" href="https://laravel.com/">Laravel Website</a></li>
<li><a target="_blank" href="https://laravel.com/docs">Laravel Docs</a></li>
<li><a target="_blank" href="https://laracasts.com">Laracasts</a></li>
<li><a target="_blank" href="https://laravel-news.com">Laravel News</a></li>
<li><a target="_blank" href="https://blog.laravel.com">Laravel Blog</a></li>
<li><a target="_blank" href="https://github.com/laravel/laravel">Laravel on GitHub</a></li>
<li><a target="_blank" href="https://github.com/chiraggude/awesome-laravel">Awesome Laravel</a></li>
<?php /**PATH C:\Users\eloko\Desktop\vol2\mysite\resources\views/laravel.blade.php ENDPATH**/ ?>