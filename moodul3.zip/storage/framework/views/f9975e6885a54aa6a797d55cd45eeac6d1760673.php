<?php $__env->startSection('title', '| Lisainfo'); ?>
<?php $__env->startSection('content'); ?>
    <div class="uk-child-width-expand@s uk-text-center uk-margin-large-top uk-width-1-1">
        <div>
            <div class="uk-card uk-card-default uk-card-body"><?php echo $__env->make('partials._img', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
        </div>
        <div>
            <div class="uk-card uk-card-default uk-card-body uk-margin-small-bottom"><?php echo $__env->make('partials._text', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php echo $__env->make('partials._buy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eloko\Desktop\TeraFlop\teraflop\resources\views/pages/detail.blade.php ENDPATH**/ ?>