<div class="uk-align-center uk-margin-large-left uk-margin-large-right">
    <h1><strong><?php echo e($products->nimi); ?></strong></h1>
    <h2><strong>Hind</strong> <?php echo e($products->hind); ?>€</h2>
    <p><?php echo e($products->näitajad); ?></p>
</div>
<?php /**PATH C:\Users\eloko\Desktop\TeraFlop\teraflop\resources\views/partials/_text.blade.php ENDPATH**/ ?>