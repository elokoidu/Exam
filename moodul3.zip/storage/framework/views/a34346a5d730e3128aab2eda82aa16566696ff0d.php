<?php if(Session::has('success')): ?>

    <div class="uk-alert-primary" uk-alert>
        <a class="uk-alert-close" uk-close></a>
        <p><?php echo e(Session::get('success')); ?></p>
    </div>

<?php endif; ?>

<?php /**PATH C:\Users\eloko\Desktop\TeraFlop\teraflop\resources\views/partials/_messages.blade.php ENDPATH**/ ?>