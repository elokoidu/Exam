<div class="uk-align-center uk-margin-large-left uk-margin-large-right">
    <p><?php echo e($products->kirjeldus); ?></p>
    <button class="uk-button-primary uk-button-large">Lisa ostukorvi</button>
</div>
<?php /**PATH C:\Users\eloko\Desktop\TeraFlop\teraflop\resources\views/partials/_buy.blade.php ENDPATH**/ ?>