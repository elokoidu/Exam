<nav class="uk-navbar-container uk-margin uk-margin-remove-bottom uk-text-bold uk-text-secondary" uk-navbar>
    <div class="uk-navbar-left uk-margin-xlarge-left">
        <div class="uk-navbar-left"><div>
                <ul class="uk-navbar-nav">
                    <li>
                        <a href="#">Tooted</a>
                        <div class="uk-navbar-dropdown">
                            <ul class="uk-nav uk-navbar-dropdown-nav">
                                <li><a href="#">Tootjad</a></li>
                                <li><a href="#">Seeriad</a></li>
                                <li><a href="#">Kõik tooted</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="#">Kampaaniad</a>
                        <div class="uk-navbar-dropdown">
                            <ul class="uk-nav uk-navbar-dropdown-nav">
                                <li><a href="#">SALE</a></li>
                                <li><a href="#">Eripakkumised</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div></div>
    </div>
    <div class="uk-navbar-center">
        <a class="uk-navbar-item uk-logo uk-width-medium" href="#"><img src="skinny.png"></a>
    </div>
    <div class="uk-navbar-right uk-margin-xlarge-right">
        <div class="uk-navbar-right"><div>
                <ul class="uk-navbar-nav">
                    <div>
                        <a class="uk-navbar-toggle" uk-search-icon href="#"></a>
                        <div class="uk-drop" uk-drop="mode: click; pos: left-center; offset: 0">
                            <form class="uk-search uk-search-navbar uk-width-1-1">
                                <input class="uk-search-input" type="search" placeholder="Otsi..." autofocus>
                            </form>
                        </div>
                    </div>
                    <li>
                        <a href="#">Konto</a>
                        <div class="uk-navbar-dropdown">
                            <ul class="uk-nav uk-navbar-dropdown-nav">
                                <li><a href="#">Logi sisse</a></li>
                                <li><a href="#">Registreeru</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="#">EST</a>
                        <div class="uk-navbar-dropdown">
                            <ul class="uk-nav uk-navbar-dropdown-nav">
                                <li><a href="#">EST</a></li>
                                <li><a href="#">ENG</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    </div>
</nav>
<?php /**PATH C:\Users\eloko\Desktop\vol2\mysite\resources\views/hero.blade.php ENDPATH**/ ?>
