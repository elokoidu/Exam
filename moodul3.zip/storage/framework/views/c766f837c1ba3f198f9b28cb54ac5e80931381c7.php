<?php $__env->startSection('title', '| Avaleht'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.things', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eloko\Desktop\vol2\mysite\resources\views/pages/welcome.blade.php ENDPATH**/ ?>